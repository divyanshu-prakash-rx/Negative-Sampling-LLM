#!/bin/bash

python data_processing/download/download_msmarco.py
python data_processing/download/download_and_prepare_tydi_train_in_st_format.py
python data_processing/download/download_and_prepare_tydi_test_in_beir_format.py
python data_processing/download/download_and_prepare_mmarco.py
python data_processing/download/download_and_prepare_miracl.py
python data_processing/download/download_and_prepare_bsard.py
python data_processing/download/download_and_prepare_geradalir.py
python data_processing/download/download_and_prepare_beir.py

git clone git@github.com:Alibaba-NLP/Multi-CPR.git data/Multi-CPR

python data_processing/download/download_and_prepare_multicpr.py
